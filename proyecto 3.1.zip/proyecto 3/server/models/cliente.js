  const mongoose = require('mongoose');
const uniqueValidator = require('mongoose-unique-validator');

let Schema = mongoose.Schema;
const AutoIncrement = require('mongoose-sequence')(mongoose);

let ClienteSchema = new Schema({

    
    
    address:{
        type:String,
        required:[true,'ingrese su direcion ']
        
    
    },
    city:{
        type:String,
        required:[true,'ingrese una ciudad ']
    },
    coutry:{
        type:String,
        required:[true,'ingrese un pais ']

    },
    district:{
        type:String,
        required:[true,'ingrese un distrito ']
    
    },
    firstName:{
        type:String,
        required:[true,'ingresa tu primer nombre ']
    },
    lastName:{
        type:String,
        required:[true,'ingresa tu segundo nombre ']
    },


     disponible:{
        type:Boolean,
        default:true
    }

});

ClienteSchema.plugin(AutoIncrement, {inc_field: 'id'},uniqueValidator, {
    message: '{PATH} Debe ser único y diferente'
});

module.exports = mongoose.model('Clientes', ClienteSchema);