
'use listingsAndReviews'
const mongoose = require('mongoose');
const uniqueValidator = require('mongoose-unique-validator');
let Schema = mongoose.Schema;

listingsAndReviewsSchema = new Schema({
    name:{
        type:String
    },
    space:{
        type:String

    },
    description:{
        type:String
    }





    
});
listingsAndReviewsSchema.plugin(uniqueValidator, {
    message: '{PATH} Debe ser único y diferente'
});

module.exports = mongoose.model('listingsAndReviews', listingsAndReviewsSchema);